const origins = [
  'http://127.0.0.1:5500',
  'http://localhost:3500',
  'http://localhost:8080',
  'http://127.0.0.1:5173',
  'http://www.finebay.co.kr',
  'https://www.finebay.co.kr'
]

module.exports = origins